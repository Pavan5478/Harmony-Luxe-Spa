﻿export const inr = (n: number) => `₹${n.toFixed(2)}`;
