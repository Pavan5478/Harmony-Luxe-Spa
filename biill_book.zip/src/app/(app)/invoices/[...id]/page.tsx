﻿import { notFound, redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { listBills } from "@/store/bills";
import { inr } from "@/lib/format";

// Catch-all route: /invoices/[...id]
type PageProps = {
  params: { id: string[] };
};

export const dynamic = "force-dynamic";

export default async function InvoicePage({ params }: PageProps) {
  const session = await getSession();
  if (!session.user) redirect("/login");

  // we only care about the first segment as the key
  const rawId = params.id?.[0] ?? "";
  const key = decodeURIComponent(rawId);

  const bills = await listBills();

  const found =
    bills.find((b: any) => String(b.billNo || "") === key) ||
    bills.find((b: any) => String(b.id || "") === key);

  if (!found) {
    notFound();
  }

  // cast to any so we can use billNo / billDate / finalizedAt
  const bill: any = found;

  const t = bill.totals || {};
  const discount = Number(t.discount || 0);
  const hasDiscount = discount > 0;
  const notes = (bill.notes || "").trim();
  const hasNotes = notes.length > 0;

  const billDateISO =
    bill.billDate || bill.finalizedAt || bill.createdAt;
  const billDate = billDateISO
    ? new Date(billDateISO)
    : new Date();

  const customer = bill.customer || {};

  // TODO: later we can load these from a Settings sheet
  const spaName = "XiphiasSpa";
  const spaAddress = [
    "123, Sample Street",
    "Some Area, City - 600001",
    "GSTIN: 33AAAAA0000A1Z5",
  ];
  const spaPhone = "+91 98765 43210";
  const spaEmail = "info@xiphiaspa.com";

  return (
    <div className="mx-auto max-w-5xl px-4 pb-10 pt-4 sm:px-6 lg:px-8">
      {/* Top bar (non-interactive – printable page) */}
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">
            Invoice
          </p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
            Bill #{bill.billNo || bill.id}
          </h1>
          <p className="mt-1 text-xs text-muted sm:text-sm">
            Printable invoice view. Use your browser&apos;s{" "}
            <span className="font-medium text-foreground">
              Print
            </span>{" "}
            option (Ctrl/Cmd + P) for A4 size.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/invoices"
            className="rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted hover:bg-background"
          >
            ← Back to invoices
          </a>
        </div>
      </div>

      {/* Printable area */}
      <div className="invoice-print rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
        {/* Header / letterhead */}
        <header className="flex flex-col gap-4 border-b border-border pb-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-lg font-semibold text-white sm:h-14 sm:w-14">
              {/* Replace with <img src="..." /> if you have a logo */}
              XS
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-tight sm:text-xl">
                {spaName}
              </h2>
              <div className="mt-1 text-[11px] text-muted sm:text-xs">
                {spaAddress.map((line: string, idx: number) => (
                  <div key={idx}>{line}</div>
                ))}
                <div className="mt-1">
                  Phone: {spaPhone} · Email: {spaEmail}
                </div>
              </div>
            </div>
          </div>

          <div className="text-right text-[11px] text-muted sm:text-xs">
            <div className="text-xs font-semibold text-foreground">
              Invoice
            </div>
            <div className="mt-1">
              <span className="font-medium text-foreground">
                Bill #
              </span>{" "}
              {bill.billNo || bill.id}
            </div>
            <div>
              <span className="font-medium text-foreground">
                Date:
              </span>{" "}
              {billDate.toLocaleDateString()}
            </div>
            <div>
              <span className="font-medium text-foreground">
                Status:
              </span>{" "}
              {bill.status || "FINAL"}
            </div>
          </div>
        </header>

        {/* Customer + meta */}
        <section className="mt-4 grid gap-4 border-b border-border pb-4 sm:grid-cols-[minmax(0,2fr)_minmax(0,1.3fr)]">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted">
              Billed to
            </p>
            <div className="mt-1 text-sm font-medium text-foreground">
              {customer.name || "Walk-in customer"}
            </div>
            <div className="mt-1 text-[11px] text-muted sm:text-xs">
              {customer.phone && <div>Phone: {customer.phone}</div>}
              {customer.email && <div>Email: {customer.email}</div>}
            </div>
          </div>

          <div className="text-[11px] text-muted sm:text-xs">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted">
              Details
            </p>
            <div className="mt-1">
              Payment mode:{" "}
              <span className="font-medium text-foreground">
                {bill.paymentMode || "—"}
              </span>
            </div>
            <div>
              Cashier:{" "}
              <span className="font-medium text-foreground">
                {bill.cashierEmail || "—"}
              </span>
            </div>
          </div>
        </section>

        {/* Line items */}
        <section className="mt-4">
          <table className="w-full border-collapse text-xs sm:text-sm">
            <thead className="border-b border-border text-[10px] uppercase tracking-wide text-muted">
              <tr>
                <th className="py-2 text-left">#</th>
                <th className="py-2 text-left">Service / item</th>
                <th className="py-2 text-left">Variant</th>
                <th className="py-2 text-right">Qty</th>
                <th className="py-2 text-right">Rate</th>
                <th className="py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {(bill.lines || []).map((l: any, idx: number) => {
                const qty = Number(l.qty || 0);
                const rate = Number(l.rate || 0);
                const amount = qty * rate;
                return (
                  <tr
                    key={idx}
                    className="border-b border-border/70 align-top"
                  >
                    <td className="py-1 pr-2">{idx + 1}</td>
                    <td className="py-1 pr-2">
                      <div className="font-medium text-foreground">
                        {l.name || "-"}
                      </div>
                      {l.itemId && (
                        <div className="text-[10px] text-muted">
                          Code: {l.itemId}
                        </div>
                      )}
                    </td>
                    <td className="py-1 pr-2">
                      {l.variant || <span className="text-muted">—</span>}
                    </td>
                    <td className="py-1 pr-2 text-right">{qty}</td>
                    <td className="py-1 pr-2 text-right">
                      {inr(rate)}
                    </td>
                    <td className="py-1 pl-2 text-right">
                      {inr(amount)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>

        {/* Totals + notes */}
        <section className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          {/* Notes – only if present */}
          <div className="flex-1 text-[11px] text-muted sm:text-xs">
            {hasNotes && (
              <>
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted">
                  Notes
                </p>
                <p className="mt-1 whitespace-pre-line text-foreground">
                  {notes}
                </p>
              </>
            )}
          </div>

          <div className="w-full max-w-xs rounded-xl border border-border bg-background px-4 py-3 text-xs sm:text-sm">
            <table className="w-full border-collapse">
              <tbody>
                <tr>
                  <td className="py-1 pr-2 text-muted">Subtotal</td>
                  <td className="py-1 pl-2 text-right">
                    {inr(t.subtotal || 0)}
                  </td>
                </tr>

                {hasDiscount && (
                  <tr>
                    <td className="py-1 pr-2 text-muted">Discount</td>
                    <td className="py-1 pl-2 text-right">
                      −{inr(discount)}
                    </td>
                  </tr>
                )}

                <tr>
                  <td className="py-1 pr-2 text-muted">Taxable value</td>
                  <td className="py-1 pl-2 text-right">
                    {inr(t.taxableBase || 0)}
                  </td>
                </tr>
                {(t.cgst || 0) > 0 && (
                  <tr>
                    <td className="py-1 pr-2 text-muted">CGST</td>
                    <td className="py-1 pl-2 text-right">
                      {inr(t.cgst || 0)}
                    </td>
                  </tr>
                )}
                {(t.sgst || 0) > 0 && (
                  <tr>
                    <td className="py-1 pr-2 text-muted">SGST</td>
                    <td className="py-1 pl-2 text-right">
                      {inr(t.sgst || 0)}
                    </td>
                  </tr>
                )}
                {(t.igst || 0) > 0 && (
                  <tr>
                    <td className="py-1 pr-2 text-muted">IGST</td>
                    <td className="py-1 pl-2 text-right">
                      {inr(t.igst || 0)}
                    </td>
                  </tr>
                )}
                {(t.roundOff || 0) !== 0 && (
                  <tr>
                    <td className="py-1 pr-2 text-muted">Round off</td>
                    <td className="py-1 pl-2 text-right">
                      {inr(t.roundOff || 0)}
                    </td>
                  </tr>
                )}
                <tr>
                  <td className="py-2 pr-2 text-[11px] font-semibold uppercase tracking-wide text-muted">
                    Grand total
                  </td>
                  <td className="py-2 pl-2 text-right text-lg font-semibold tracking-tight">
                    {inr(t.grandTotal || 0)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-6 border-t border-border pt-3 text-center text-[10px] text-muted print:text-[9px]">
          <div>Thank you for choosing {spaName}. Relax, refresh, rejuvenate.</div>
          <div className="mt-1">
            This is a computer-generated invoice. No signature required.
          </div>
        </footer>
      </div>
    </div>
  );
}